package PackagePola

interface InterfaceClass {
        fun membuatPola()
}